% find_fourier_BUF
% takes in a BUF and time axis as well as an initial guess at the 4 fourier
% BUF parameters (shape and scale pars of 2 gamma distributions) and
% returns a least-squares fit
% takes input of an "empirical" BUF as well as its time axis for
% interpolation with the BUFproposed in compare_buildup_functions

%find_fourier_BUF(BUF,tax,bufpars0)

clear;
%generate_simulated_BUF;
KPushETs_ss;

% need to start with some sort of empirical buildup function
[BUF tax] = make_buildup_function3(durs,.01,10);

%%

% I use the data to find estimates for starting parameters
durs1 = durs(durs(:,2)==1,1);
[g1 alpha beta fVal] = find_gamma_pars(durs1);

durs2 = durs(durs(:,2)==2,1);
[g2 alpha beta fVal] = find_gamma_pars(durs2);

g1(2) = 1/g1(2); g2(2) = 1/g2(2);   % durn it I still need to fix everything to k/theta pars
bufpars0 = [g1' g2'];

f = @(bufpars)compare_buildup_functions(bufpars,BUF,tax); % this interpolates the two BUFS
                                                        % to the same time
                                                        % resolution and
                                                        % calculates error
[bufpars fval] = fminsearch(f,bufpars0);

[BUFfit t] = make_fourier_buildup_function(bufpars);
[error Rsquared_fit] = compare_buildup_functions2(bufpars,BUF,tax);

if exist('nSwitches','var')
    [err Rsq_aPriori] = compare_buildup_functions2(bufparsU,BUF,tax);
end

%BUF_up = interp1(t,BUFfit,tax);

plot(t,BUFfit,tax,BUF); title(num2str(bufpars))




