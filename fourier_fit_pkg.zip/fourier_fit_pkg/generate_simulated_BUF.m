% generate_simulated_BUF

nSwitches = 400;
bufparsU = [2,.5,5,.5];

a0 = bufparsU(1); th0 = bufparsU(2); a1 = bufparsU(3); th1 = bufparsU(4); % i think? unless it's theta

% Now I generate the dominance durations from each distribution for
% nSwitches/2 samples on each of nTrials
durs1=gamrnd(a0,th0,nSwitches/2,1);

% dominance durations for percept 2
durs2=gamrnd(a1,th1,nSwitches/2,1);

durs=[];
durs(1:2:length(durs1)+length(durs2)-1,:)=[durs1 ones(length(durs1),1)];
durs(2:2:length(durs1)+length(durs2),:)=[durs2 ones(length(durs2),1)*2];

%[BUF tax] = make_buildup_function3(durs, .001, 10);