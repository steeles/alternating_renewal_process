% test whether u2>u1, use the inds to find dominance durations

function test_levelts_props(u1,u2,t)



