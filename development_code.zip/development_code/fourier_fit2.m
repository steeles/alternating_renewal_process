% fourier_fit2

function find_fourier_BUF(BUF,tax,bufpars0)